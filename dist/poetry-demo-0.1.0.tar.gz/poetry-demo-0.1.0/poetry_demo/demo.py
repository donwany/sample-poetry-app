def add(a: int, b: int) -> int:
    return a + b


def main():
    print(add(58, 99))


if __name__ == '__main__':
    main()
