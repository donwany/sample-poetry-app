# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry_demo']

package_data = \
{'': ['*']}

install_requires = \
['arrow>=1.2.3,<2.0.0',
 'ghananews-scraper>=1.0.25,<2.0.0',
 'pendulum>=2.1.2,<3.0.0']

entry_points = \
{'console_scripts': ['greet = greet.location:cli']}

setup_kwargs = {
    'name': 'poetry-demo',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'donwany',
    'author_email': 'user.aerogramme@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
